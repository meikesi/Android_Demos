﻿for(var i = 0; i < 175; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u133'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u151'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u173'] = 'center';
u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('支付.html');

}
});
gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u139'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u3'] = 'center';
u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u147'] = 'center';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u153'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u165'] = 'center';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u35'] = 'center';
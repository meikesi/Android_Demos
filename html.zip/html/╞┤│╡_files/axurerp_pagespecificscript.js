﻿for(var i = 0; i < 51; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u34'] = 'top';
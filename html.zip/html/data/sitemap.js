﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o,i,[_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C)]),_(c,D,e,f,g,E,i,[_(c,F,e,f,g,G),_(c,H,e,f,g,I),_(c,J,e,f,g,K),_(c,L,e,f,g,M),_(c,N,e,f,g,O)]),_(c,P,e,f,g,Q),_(c,R,e,f,g,S),_(c,T,e,f,g,U),_(c,V,e,f,g,W),_(c,X,e,f,g,Y),_(c,Z,e,f,g,ba)])]);}; 
var b="rootNodes",c="pageName",d="拼车",e="type",f="Wireframe",g="url",h="拼车.html",i="children",j="分享--推广手段",k="分享--推广手段.html",l="首页",m="首页.html",n="乘客",o="乘客.html",p="约车上班、下班约车",q="约车上班、下班约车.html",r="支付",s="支付.html",t="确认搭乘",u="确认搭乘.html",v="取消预约",w="取消预约.html",x="其他预约",y="其他预约.html",z="我的预约",A="我的预约.html",B="约车公约",C="约车公约.html",D="车主",E="车主.html",F="车主认证",G="车主认证.html",H="上班订单、下班订单",I="上班订单、下班订单.html",J="附近订单",K="附近订单.html",L="车主接单流程",M="车主接单流程.html",N="我的订单",O="我的订单.html",P="车主详情",Q="车主详情.html",R="广告栏",S="广告栏.html",T="菜单",U="菜单.html",V="登录、注册",W="登录、注册.html",X="评价评分系统",Y="评价评分系统.html",Z="提现",ba="提现.html";
return _creator();
})();

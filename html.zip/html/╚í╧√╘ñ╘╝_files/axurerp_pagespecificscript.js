﻿for(var i = 0; i < 38; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u29'] = 'center';document.getElementById('u32_img').tabIndex = 0;
HookClick('u32', false);

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('提现.html'), "");

}
});
gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u14'] = 'center';HookClick('u4', false);
gv_vAlignTable['u1'] = 'center';
$axure.eventManager.blur('u10', function(e) {

if ((GetWidgetText('u10')) == ('')) {

}
else
if ((GetWidgetValueLength('u10')) > Number('2048')) {

}
else
if (true) {

}
});
gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u24'] = 'center';HookClick('u25', false);
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u31'] = 'center';document.getElementById('u34_img').tabIndex = 0;
HookClick('u34', false);

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	NewTab($axure.globalVariableProvider.getLinkUrl('提现.html'), "");

}
});

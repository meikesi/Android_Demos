﻿for(var i = 0; i < 61; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u18'] = 'center';
u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('车主认证.html');

}
});
gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u55'] = 'center';